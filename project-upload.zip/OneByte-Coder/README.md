# OneByte Coder

**An AI-assisted development workspace for planning, coding, reviewing, and preparing projects for release.**

OneByte Coder is an early, extensible foundation for the workflow described in the product brief: project workspaces, a file tree, an in-app code editor, configurable OpenAI-compatible providers, queued agent tasks, a skills library, code review, and GitHub publishing foundations.

> Status: prototype / foundation (v0.1.0). This is not yet a full autonomous Replit replacement. Runtime orchestration, real browser/device preview, visual feedback loops, isolated terminal execution, and release signing are staged for later milestones.

## Current capabilities

- Dark responsive workspace UI with project cards, explorer tree, Monaco editor, agent panel, plan panel, and review panel.
- Provider settings with Base URL and API key; fetches model IDs from OpenAI-compatible `/models` endpoints.
- Agent endpoint that sends the project brief, selected task, current files, and skill instructions to an OpenAI-compatible `/chat/completions` endpoint and expects structured JSON file changes.
- Sequential task queue in the UI.
- AI-assisted static code review with explicit caveats: model review is not a security certification.
- GitHub publishing API foundation that can create a repository and upload files using a user-supplied token with repository creation and contents permissions.
- Skills starter library in `skills/skills.md`.
- GitHub Actions workflows for GitHub Pages deployment and debug APK artifact generation.

## Architecture

```text
frontend/  React + Vite + Monaco + Capacitor wrapper
backend/   FastAPI provider proxy, agent task and review endpoints, GitHub publishing endpoint
skills/    Reusable project and quality instructions
.github/   Pages and Android APK CI workflows
```

## Run locally

### 1. Backend

```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python run.py
```

API health check: `http://localhost:8000/health`

### 2. Frontend

```bash
cd frontend
npm install
npm run dev
```

Open `http://localhost:5173`.

The API key is currently held in React session state and sent to the local backend only for each request. Do not deploy this prototype as a multi-user service without adding authentication, rate limits, encrypted secret storage, per-user isolation, audit logging, and CSRF/origin protections.

## Provider compatibility

The provider must expose OpenAI-compatible endpoints:

- `GET /v1/models`
- `POST /v1/chat/completions`

Use a Base URL ending in `/v1` (or the equivalent API prefix for your provider). Model metadata such as price, context window, and coding benchmarks is not standardized by `/models`; this prototype intentionally does not invent those values.

## GitHub permissions

For repository creation and pushing files, the token generally needs repository administration/create permission plus contents write permission. Fine-grained token permissions depend on whether the repository already exists and the account policy. The API currently publishes to the authenticated user's own account only. Keep tokens out of source code, screenshots, prompts, and logs.

## Android APK

The Android workflow builds a **debug APK** and uploads it as a GitHub Actions artifact. It is not a signed Play Store release. To build it after pushing the repository:

1. Open **Actions → Build Android APK → Run workflow**.
2. Wait for the workflow to finish.
3. Download `onebyte-coder-debug-apk` from the run's Artifacts section.

A signed release requires a keystore and GitHub Actions secrets; do not commit signing credentials.

## Important implementation boundaries

- The current Preview pane is a designed placeholder. A real preview requires project runtime provisioning, port discovery, reverse proxying, and browser/device capture.
- The current editor edits workspace files in browser memory; durable filesystem persistence and Git worktrees are not implemented yet.
- The current agent applies complete file replacements after a structured response; true token-by-token editor streaming and patch/diff approval are planned next.
- The review endpoint analyzes supplied source text; it does not run SAST/DAST, dependency scanners, tests, or penetration testing.
- GitHub Pages workflow deploys the frontend only. A backend API must be hosted separately and configured through `VITE_API_BASE`.
- APK and EXE builds require platform-specific build environments. Windows EXE packaging is not implemented in this release.

## Roadmap

1. Persistent project filesystem, ZIP import/export, Git worktrees, and diff approval.
2. True streamed code generation with live editor updates and sequential queue recovery.
3. Isolated Docker runtimes for Python, Node, CLI, and web projects; terminal WebSocket.
4. Browser automation and screenshot capture for real visual QA and correction loops.
5. Expo/Android runtime bridge and APK packaging; Windows executable packaging.
6. Verified provider catalog for pricing/context metadata and provider health probes.
7. Hardened GitHub publish pipeline, dependency scanning, test gates, Pages configuration, and release details.

## License

MIT (see `LICENSE`).
